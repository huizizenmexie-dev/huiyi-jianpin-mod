# 轻量级多语言方案实施报告

## ✅ 方案变更

**原方案**：使用 i18next + react-i18next + i18next-browser-languagedetector

**新方案**：自定义轻量级 Hook，零依赖

---

## 🎯 核心原则

> **URL 决定语言 + JSON 翻译文件 + 自定义轻量 Hook + RTL Hook**

- ❌ 不安装 i18next
- ❌ 不安装 react-i18next
- ❌ 不安装 browser-language-detector
- ❌ 不使用在线翻译 SaaS
- ❌ 不依赖 CDN

---

## 📁 文件结构

```
client/
├── src/
│   ├── hooks/
│   │   ├── useI18n.ts        # 🆕 轻量级 i18n hook
│   │   └── useRTL.ts         # 🆕 RTL 支持 hook
│   ├── components/
│   │   ├── LanguageSwitcher.tsx  # ✏️ 已更新
│   │   └── Layout.tsx           # ✏️ 已更新
│   └── App.tsx                   # ✏️ 已更新
└── public/
    └── locales/
        ├── en/translation.json
        ├── zh-CN/translation.json
        ├── pt-BR/translation.json
        ├── fr/translation.json
        ├── ar/translation.json
        └── es/translation.json
```

---

## 🔧 核心实现

### 1. useI18n Hook

**文件**：`client/src/hooks/useI18n.ts`

```typescript
const { t, locale, loading, locales } = useI18n(currentLocale);

// 使用
<h1>{t('homepage.hero_title')}</h1>
```

**特性**：
- 从 URL 读取语言，不依赖浏览器设置
- 翻译文件按需加载
- 内置缓存机制
- 英语兜底

### 2. useRTL Hook

**文件**：`client/src/hooks/useRTL.ts`

```typescript
const isRTL = useRTL();
// 自动设置 document.documentElement.dir
```

**支持的 RTL 语言**：
- 阿拉伯语 (ar)
- 希伯来语 (he)
- 波斯语 (fa)
- 乌尔都语 (ur)

### 3. LanguageSwitcher 组件

**文件**：`client/src/components/LanguageSwitcher.tsx`

- 使用 wouter 的 useLocation 获取当前路径
- 切换语言时更新 URL，不依赖任何状态管理
- URL 是语言的唯一来源

---

## 🌍 URL 结构

| 语言 | URL 示例 |
|------|----------|
| 英语 | `/en/products` |
| 中文 | `/zh-CN/products` |
| 巴西葡萄牙语 | `/pt-BR/products` |
| 法语 | `/fr/products` |
| 阿拉伯语 | `/ar/products` |
| 西班牙语 | `/es/products` |

---

## 💻 使用示例

### 在页面组件中使用

```tsx
import { useLocation } from "wouter";
import { useI18n, getLocaleFromPath } from "@/hooks/useI18n";
import { useRTL } from "@/hooks/useRTL";

export default function ProductsPage() {
  const [location] = useLocation();
  const locale = getLocaleFromPath(location);
  const { t, loading } = useI18n(locale);
  const isRTL = useRTL();

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div dir={isRTL ? "rtl" : "ltr"}>
      <h1>{t('products_page.title')}</h1>
      <p>{t('products_page.description')}</p>
    </div>
  );
}
```

### 在 Layout 中使用

```tsx
import { useRTL } from "@/hooks/useRTL";

function Navbar() {
  const isRTL = useRTL();

  return (
    <nav className={isRTL ? "flex-row-reverse" : ""}>
      {/* ... */}
    </nav>
  );
}
```

---

## ✨ 优势

| 特性 | 说明 |
|------|------|
| **零依赖** | 不需要安装任何 i18n 库 |
| **URL 优先** | URL 决定语言，不受浏览器设置影响 |
| **按需加载** | 翻译文件按需加载，不影响首屏性能 |
| **缓存机制** | 已加载的翻译文件会被缓存 |
| **英语兜底** | 加载失败时自动回退到英语 |
| **RTL 支持** | 阿拉伯语等 RTL 语言自动适配 |
| **SEO 友好** | 每种语言有独立 URL |

---

## 📋 下一步

### 1. 更新页面组件

在各页面组件中使用 `useI18n` hook：

```tsx
import { useLocation } from "wouter";
import { useI18n, getLocaleFromPath } from "@/hooks/useI18n";

export default function MyPage() {
  const [location] = useLocation();
  const locale = getLocaleFromPath(location);
  const { t } = useI18n(locale);

  return <h1>{t('page.title')}</h1>;
}
```

### 2. 补充翻译内容

根据实际页面内容更新翻译文件：

- `client/public/locales/en/translation.json`
- `client/public/locales/zh-CN/translation.json`
- `client/public/locales/pt-BR/translation.json`
- `client/public/locales/fr/translation.json`
- `client/public/locales/ar/translation.json`
- `client/public/locales/es/translation.json`

### 3. 删除旧文件

已删除：
- `client/src/i18n.ts` (使用 i18next 的旧版本)

---

## 🎯 关键原则

> **客户打开 `/pt-BR/products`，就必须稳定显示巴西葡语，而不是因为他的浏览器设置成英语又跳回英文。**

这个方案完全满足这个要求：
- URL 是语言的唯一来源
- 浏览器语言设置不影响显示
- 语言切换通过 URL 更新实现

---

**文档版本**：v3.0
**最后更新**：2026-07-01
**方案**：轻量级自建方案，零依赖
