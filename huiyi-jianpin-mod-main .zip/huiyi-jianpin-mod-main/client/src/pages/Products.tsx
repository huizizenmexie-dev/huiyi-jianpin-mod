/*
 * DESIGN: Agricultural Documentary — Cinematic Storytelling
 * Products listing: Filter bar, product cards in grid
 */
import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { ChevronRight, ArrowRight } from "lucide-react";
import { products, filterCategories } from "@/lib/productData";
import { applyPageSeo, buildBreadcrumbSchema } from "@/lib/seo";

const HEADER_IMG =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663542071909/f8VjjnvUts7et3XqyBkjBm/banner-soybean-harvest-4Swmtb4Bj6WCpQxs3QVKpV.webp";

function FadeIn({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ease-out ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      } ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

export default function Products() {
  const [activeFilter, setActiveFilter] = useState("All");

  useEffect(
    () =>
      applyPageSeo({
        title: "Soy Lecithin & Phospholipid Products | Stable B2B Supply",
        description:
          "Explore soy lecithin, phosphatidylcholine, phosphatidylserine, soy protein and dietary fiber systems from Huiyi Jianpin, built for reliable sourcing and global B2B supply.",
        keywords:
          "soy lecithin products, phospholipid systems, phosphatidylcholine supplier, phosphatidylserine supplier, reliable lecithin sourcing, stable B2B ingredient supply",
        path: "/products",
        image: HEADER_IMG,
        jsonLd: [
          buildBreadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "Products", path: "/products" },
          ]),
        ],
      }),
    []
  );

  const filtered =
    activeFilter === "All"
      ? products
      : products.filter((p) => p.category.includes(activeFilter));

  return (
    <div>
      {/* Header */}
      <section className="relative h-[35vh] min-h-[280px] flex items-end overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${HEADER_IMG})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
        <div className="relative container pb-10">
          <nav className="flex items-center gap-2 text-sm text-white/60 mb-4">
            <Link href="/" className="hover:text-white transition-colors">Home</Link>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="text-white">Products</span>
          </nav>
          <h1 className="font-heading font-bold text-4xl md:text-5xl text-white">
            Natural Phospholipid Systems
          </h1>
          <p className="text-harvest-gold font-heading font-medium text-lg mt-2">
            Reliable sourcing for stable global B2B supply.
          </p>
        </div>
      </section>

      {/* Intro + Filter */}
      <section className="py-8 bg-warm-ivory border-b border-border sticky top-16 z-30 backdrop-blur-sm" style={{ backgroundColor: "rgba(245, 242, 235, 0.95)" }}>
        <div className="container">
          <p className="text-medium-gray text-sm mb-4 max-w-3xl">
            From standard soy lecithin to high-purity phospholipid derivatives, our product systems support food, nutrition, pharma, cosmetics, feed, and plant-based applications. Each product is backed by stable production capacity, documented specifications, and batch-level quality traceability.
          </p>
          <div className="flex flex-wrap gap-2">
            {filterCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveFilter(cat)}
                className={`px-4 py-1.5 text-sm font-medium rounded-full transition-all duration-200 ${
                  activeFilter === cat
                    ? "bg-earth-green text-white"
                    : "bg-white text-medium-gray border border-border hover:border-earth-green hover:text-earth-green"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Product Grid */}
      <section className="py-12 lg:py-20 bg-warm-ivory">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((product, i) => (
              <FadeIn key={product.id} delay={i * 60}>
                <Link href={`/products/${product.slug}`}>
                  <div className="group bg-white rounded-lg overflow-hidden border border-transparent hover:border-earth-green shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer h-full flex flex-col">
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={product.image}
                        alt={`${product.name} for stable ingredient sourcing`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="p-5 flex-1 flex flex-col">
                      <h3 className="font-heading font-semibold text-deep-brown text-lg mb-1 group-hover:text-earth-green transition-colors">
                        {product.name}
                      </h3>
                      <p className="text-medium-gray text-sm mb-3 line-clamp-2">
                        {product.subtitle}
                      </p>
                      <div className="mt-auto pt-3 border-t border-border">
                        <p className="text-xs font-mono text-earth-green font-medium">
                          {product.listingSpecs}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 mt-3 text-earth-green text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                        View Details
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>
                </Link>
              </FadeIn>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-16">
              <p className="text-medium-gray">No products match this filter.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
