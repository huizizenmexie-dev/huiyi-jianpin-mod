import { useEffect, useState, useCallback } from "react";

type TranslationData = Record<string, any>;

const locales = ["en", "zh-CN", "pt-BR", "fr", "ar", "es"] as const;
type Locale = (typeof locales)[number];

const DEFAULT_LOCALE: Locale = "en";

// Cache loaded translations
const translationCache: Record<string, TranslationData> = {};

function getByPath(data: TranslationData, path: string): string {
  const result = path.split(".").reduce((value, key) => value?.[key], data);
  return typeof result === "string" ? result : path;
}

export function useI18n(locale?: string) {
  const [messages, setMessages] = useState<TranslationData>({});
  const [loading, setLoading] = useState(true);

  // Validate and normalize locale
  const validLocale: Locale = locales.includes(locale as Locale)
    ? (locale as Locale)
    : DEFAULT_LOCALE;

  useEffect(() => {
    let cancelled = false;

    async function loadTranslation() {
      setLoading(true);

      // Check cache first
      if (translationCache[validLocale]) {
        setMessages(translationCache[validLocale]);
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(`/locales/${validLocale}/translation.json`);
        if (!response.ok) throw new Error(`Failed to load locale: ${validLocale}`);
        const data = await response.json();

        if (!cancelled) {
          translationCache[validLocale] = data;
          setMessages(data);
        }
      } catch (error) {
        console.warn(`Failed to load ${validLocale}, falling back to ${DEFAULT_LOCALE}`);

        // Fallback to default locale
        if (validLocale !== DEFAULT_LOCALE) {
          if (translationCache[DEFAULT_LOCALE]) {
            setMessages(translationCache[DEFAULT_LOCALE]);
          } else {
            try {
              const fallbackResponse = await fetch(`/locales/${DEFAULT_LOCALE}/translation.json`);
              if (fallbackResponse.ok) {
                const fallbackData = await fallbackResponse.json();
                if (!cancelled) {
                  translationCache[DEFAULT_LOCALE] = fallbackData;
                  setMessages(fallbackData);
                }
              }
            } catch {
              // Silent fail
            }
          }
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    loadTranslation();

    return () => {
      cancelled = true;
    };
  }, [validLocale]);

  const t = useCallback(
    (key: string): string => {
      return getByPath(messages, key);
    },
    [messages]
  );

  return { t, locale: validLocale, loading, locales };
}

// Helper to extract locale from URL path
export function getLocaleFromPath(pathname: string): Locale {
  const segments = pathname.split("/").filter(Boolean);
  const firstSegment = segments[0];

  if (locales.includes(firstSegment as Locale)) {
    return firstSegment as Locale;
  }

  return DEFAULT_LOCALE;
}

// Helper to get path without locale prefix
export function getPathWithoutLocale(pathname: string): string {
  const segments = pathname.split("/").filter(Boolean);
  const firstSegment = segments[0];

  if (locales.includes(firstSegment as Locale)) {
    return "/" + segments.slice(1).join("/");
  }

  return pathname;
}

// Helper to build URL with locale prefix
export function buildLocalizedPath(locale: Locale, path: string): string {
  const cleanPath = path.startsWith("/") ? path : `/${path}`;
  return `/${locale}${cleanPath === "/" ? "" : cleanPath}`;
}

export type { Locale };
