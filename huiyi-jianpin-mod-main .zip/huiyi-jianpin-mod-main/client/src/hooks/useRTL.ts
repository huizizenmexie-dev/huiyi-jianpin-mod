import { useEffect } from "react";
import { useLocation } from "wouter";
import { getLocaleFromPath } from "./useI18n";

// RTL languages
const RTL_LANGUAGES = ["ar", "he", "fa", "ur"];

export function useRTL() {
  const [location] = useLocation();
  const locale = getLocaleFromPath(location);
  const isRTL = RTL_LANGUAGES.includes(locale);

  useEffect(() => {
    document.documentElement.dir = isRTL ? "rtl" : "ltr";
    document.documentElement.lang = locale;
  }, [locale, isRTL]);

  return isRTL;
}
